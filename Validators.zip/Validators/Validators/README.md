using System;

namespace Validators.Validators
{
    public class BaseValidatorsValidators
    {
        public BaseValidatorsValidators()
        {
            Console.WriteLine("Base class initialized in BaseValidatorsValidators");
        }
    }
}