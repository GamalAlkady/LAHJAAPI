using ApiCore.DyModels.Dso.ResponseFilters;
using AutoGenerator;
using AutoGenerator.Conditions;
using AutoGenerator.Helper.Translation;
using LAHJAAPI.Models;
using System;

namespace ApiCore.Validators
{
    public class AdvertisementValidator : BaseValidator<AdvertisementResponseFilterDso, AdvertisementValidatorStates>, ITValidator
    {
        public AdvertisementValidator(IConditionChecker checker) : base(checker)
        {
        }

        protected override void InitializeConditions()
        {
            _provider.Register(AdvertisementValidatorStates.IsActive, new LambdaCondition<AdvertisementResponseFilterDso>(nameof(AdvertisementValidatorStates.IsActive), context => IsActive(context), "Advertisement is not active"));
        }

        private bool IsActive(AdvertisementResponseFilterDso context)
        {
            if (context != null)
            {
                return true;
            }

            return false;
        }

        [RegisterConditionValidator(typeof(ServiceValidatorStates), ServiceValidatorStates.IsActive, "Id is required")]
        private Task<ConditionResult> Validate(DataFilter<string, Service> f)
        {
            bool valid = true;
            return valid
                ? ConditionResult.ToSuccessAsync(f.Share)
                : ConditionResult.ToFailureAsync(f.Share, "Id is required");
        }
    } //
    //  Base
    public  enum  AdvertisementValidatorStates //
    { IsActive ,  IsFull ,  IsValid ,  //
    }

}