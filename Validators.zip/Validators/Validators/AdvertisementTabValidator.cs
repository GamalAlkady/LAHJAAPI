// ===== File: ApplicationUserValidator.cs =====
using ApiCore.Validators;


using ApiCore.Validators.Conditions;

using AutoGenerator.Conditions;
using LAHJAAPI.Models;
using System.Threading.Tasks;

namespace LAHJAAPI.Validators.v1
{
    public enum ApplicationUserValidatorStates
    {
        // Inherit or redefine common states if needed
        HasId = GeneralValidatorStates.HasId,
        HasValidEmail = GeneralValidatorStates.HasValidEmail,
        IsActive, // Opposite of IsArchived
        IsArchived = GeneralValidatorStates.IsArchived,
        HasFirstName,
        HasLastName,
        HasSubscription // New state
    }

    public class ApplicationUserValidator : ValidatorContext<ApplicationUser, ApplicationUserValidatorStates>
    {
        public ApplicationUserValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(ApplicationUserValidatorStates), ApplicationUserValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, ApplicationUser> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ApplicationUser.Id), "User ID is missing");

        [RegisterConditionValidator(typeof(ApplicationUserValidatorStates), ApplicationUserValidatorStates.HasValidEmail)]
        private Task<ConditionResult> ValidateHasValidEmail(DataFilter<string, ApplicationUser> f) =>
            ValidateEmail(f, nameof(ApplicationUser.Email), "Invalid or missing email address");

        [RegisterConditionValidator(typeof(ApplicationUserValidatorStates), ApplicationUserValidatorStates.HasFirstName)]
        private Task<ConditionResult> ValidateHasFirstName(DataFilter<string, ApplicationUser> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ApplicationUser.FirstName), "First name is missing");

        [RegisterConditionValidator(typeof(ApplicationUserValidatorStates), ApplicationUserValidatorStates.HasLastName)]
        private Task<ConditionResult> ValidateHasLastName(DataFilter<string, ApplicationUser> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ApplicationUser.LastName), "Last name is missing");

        [RegisterConditionValidator(typeof(ApplicationUserValidatorStates), ApplicationUserValidatorStates.IsActive)]
        private Task<ConditionResult> ValidateIsActive(DataFilter<string, ApplicationUser> f) =>
            ValidateBoolProperty(f, nameof(ApplicationUser.IsArchived), false, "User is archived");

        [RegisterConditionValidator(typeof(ApplicationUserValidatorStates), ApplicationUserValidatorStates.IsArchived)]
        private Task<ConditionResult> ValidateIsArchived(DataFilter<string, ApplicationUser> f) =>
            ValidateBoolProperty(f, nameof(ApplicationUser.IsArchived), true, "User is not archived");

        [RegisterConditionValidator(typeof(ApplicationUserValidatorStates), ApplicationUserValidatorStates.HasSubscription)]
        private Task<ConditionResult> ValidateHasSubscription(DataFilter<string, ApplicationUser> f) =>
            ValidatePropertyExists(f, nameof(ApplicationUser.Subscription), "User does not have a subscription");

    }
}

// ===== File: AuthorizationSessionValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum AuthorizationSessionValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasSessionToken,
        IsActive = GeneralValidatorStates.IsActive,
        HasUser,
        IsExpired // New state: EndTime is set and in the past
    }

    public class AuthorizationSessionValidator : ValidatorContext<AuthorizationSession, AuthorizationSessionValidatorStates>
    {
        public AuthorizationSessionValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(AuthorizationSessionValidatorStates), AuthorizationSessionValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, AuthorizationSession> f) =>
             ValidateStringPropertyNotEmpty(f, nameof(AuthorizationSession.Id), "Session ID is missing");

        [RegisterConditionValidator(typeof(AuthorizationSessionValidatorStates), AuthorizationSessionValidatorStates.HasSessionToken)]
        private Task<ConditionResult> ValidateHasSessionToken(DataFilter<string, AuthorizationSession> f) =>
             ValidateStringPropertyNotEmpty(f, nameof(AuthorizationSession.SessionToken), "Session token is missing");

        [RegisterConditionValidator(typeof(AuthorizationSessionValidatorStates), AuthorizationSessionValidatorStates.IsActive)]
        private Task<ConditionResult> ValidateIsActive(DataFilter<string, AuthorizationSession> f) =>
            ValidateBoolProperty(f, nameof(AuthorizationSession.IsActive), true, "Session is not active");

        [RegisterConditionValidator(typeof(AuthorizationSessionValidatorStates), AuthorizationSessionValidatorStates.HasUser)]
        private Task<ConditionResult> ValidateHasUser(DataFilter<string, AuthorizationSession> f) =>
             ValidateStringPropertyNotEmpty(f, nameof(AuthorizationSession.UserId), "User ID is missing from session");

        [RegisterConditionValidator(typeof(AuthorizationSessionValidatorStates), AuthorizationSessionValidatorStates.IsExpired)]
        private Task<ConditionResult> ValidateIsExpired(DataFilter<string, AuthorizationSession> f)
        {
            bool isExpired = f.Share?.EndTime != null && f.Share.EndTime.Value < DateTime.UtcNow;
            return isExpired
                ? ConditionResult.ToSuccessAsync(true, "Session has expired")
                : ConditionResult.ToFailureAsync(false, "Session is not expired or has no end time");
        }
    }
}

// ===== File: FAQItemValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum FAQItemValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasQuestion,
        HasAnswer,
        HasTag = GeneralValidatorStates.HasTags // Reuse HasTags for single Tag property
    }

    public class FAQItemValidator : ValidatorContext<FAQItem, FAQItemValidatorStates>
    {
        public FAQItemValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(FAQItemValidatorStates), FAQItemValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, FAQItem> f) =>
             ValidateStringPropertyNotEmpty(f, nameof(FAQItem.Id), "FAQ Item ID is missing");

        [RegisterConditionValidator(typeof(FAQItemValidatorStates), FAQItemValidatorStates.HasQuestion)]
        private Task<ConditionResult> ValidateHasQuestion(DataFilter<string, FAQItem> f) =>
             ValidateStringPropertyNotEmpty(f, nameof(FAQItem.Question), "FAQ question is missing");

        [RegisterConditionValidator(typeof(FAQItemValidatorStates), FAQItemValidatorStates.HasAnswer)]
        private Task<ConditionResult> ValidateHasAnswer(DataFilter<string, FAQItem> f) =>
             ValidateStringPropertyNotEmpty(f, nameof(FAQItem.Answer), "FAQ answer is missing");

        [RegisterConditionValidator(typeof(FAQItemValidatorStates), FAQItemValidatorStates.HasTag)]
        private Task<ConditionResult> ValidateHasTag(DataFilter<string, FAQItem> f) =>
             ValidateStringPropertyNotEmpty(f, nameof(FAQItem.Tag), "FAQ tag is missing");
    }
}

// ===== File: CategoryTabValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum CategoryTabValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName,
        IsActive // Using Active property
    }

    public class CategoryTabValidator : ValidatorContext<CategoryTab, CategoryTabValidatorStates>
    {
        public CategoryTabValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(CategoryTabValidatorStates), CategoryTabValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, CategoryTab> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(CategoryTab.Id), "CategoryTab ID is missing");

        [RegisterConditionValidator(typeof(CategoryTabValidatorStates), CategoryTabValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, CategoryTab> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(CategoryTab.Name), "CategoryTab name is missing");

        [RegisterConditionValidator(typeof(CategoryTabValidatorStates), CategoryTabValidatorStates.IsActive)]
        private Task<ConditionResult> ValidateIsActive(DataFilter<string, CategoryTab> f) =>
            ValidateBoolProperty(f, nameof(CategoryTab.Active), true, "CategoryTab is not active");
    }
}

// ===== File: TypeModelValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum TypeModelValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName,
        IsActive // Using Active property
    }

    public class TypeModelValidator : ValidatorContext<TypeModel, TypeModelValidatorStates>
    {
        public TypeModelValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(TypeModelValidatorStates), TypeModelValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, TypeModel> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(TypeModel.Id), "TypeModel ID is missing");

        [RegisterConditionValidator(typeof(TypeModelValidatorStates), TypeModelValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, TypeModel> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(TypeModel.Name), "TypeModel name is missing");

        [RegisterConditionValidator(typeof(TypeModelValidatorStates), TypeModelValidatorStates.IsActive)]
        private Task<ConditionResult> ValidateIsActive(DataFilter<string, TypeModel> f) =>
            ValidateBoolProperty(f, nameof(TypeModel.Active), true, "TypeModel is not active");
    }
}

// ===== File: DialectValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum DialectValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName,
        HasLanguage // Check LanguageId property
    }

    public class DialectValidator : ValidatorContext<Dialect, DialectValidatorStates>
    {
        public DialectValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(DialectValidatorStates), DialectValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Dialect> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Dialect.Id), "Dialect ID is missing");

        [RegisterConditionValidator(typeof(DialectValidatorStates), DialectValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, Dialect> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Dialect.Name), "Dialect name is missing");

        [RegisterConditionValidator(typeof(DialectValidatorStates), DialectValidatorStates.HasLanguage)]
        private Task<ConditionResult> ValidateHasLanguage(DataFilter<string, Dialect> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Dialect.LanguageId), "Language ID is missing from dialect");
    }
}

// ===== File: AdvertisementValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum AdvertisementValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasTitle,
        IsActive, // Using Active property
        HasValidUrl = GeneralValidatorStates.HasValidUri // Check Url property
    }

    public class AdvertisementValidator : ValidatorContext<Advertisement, AdvertisementValidatorStates>
    {
        public AdvertisementValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(AdvertisementValidatorStates), AdvertisementValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Advertisement> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Advertisement.Id), "Advertisement ID is missing");

        [RegisterConditionValidator(typeof(AdvertisementValidatorStates), AdvertisementValidatorStates.HasTitle)]
        private Task<ConditionResult> ValidateHasTitle(DataFilter<string, Advertisement> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Advertisement.Title), "Advertisement title is missing");

        [RegisterConditionValidator(typeof(AdvertisementValidatorStates), AdvertisementValidatorStates.IsActive)]
        private Task<ConditionResult> ValidateIsActive(DataFilter<string, Advertisement> f) =>
            ValidateBoolProperty(f, nameof(Advertisement.Active), true, "Advertisement is not active");

        [RegisterConditionValidator(typeof(AdvertisementValidatorStates), AdvertisementValidatorStates.HasValidUrl)]
        private Task<ConditionResult> ValidateHasValidUrl(DataFilter<string, Advertisement> f) =>
            ValidateUri(f, nameof(Advertisement.Url), "Invalid or missing URL for advertisement");
    }
}

// ===== File: AdvertisementTabValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum AdvertisementTabValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasTitle,
        HasAdvertisement // Check AdvertisementId property
    }

    public class AdvertisementTabValidator : ValidatorContext<AdvertisementTab, AdvertisementTabValidatorStates>
    {
        public AdvertisementTabValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(AdvertisementTabValidatorStates), AdvertisementTabValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, AdvertisementTab> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(AdvertisementTab.Id), "AdvertisementTab ID is missing");

        [RegisterConditionValidator(typeof(AdvertisementTabValidatorStates), AdvertisementTabValidatorStates.HasTitle)]
        private Task<ConditionResult> ValidateHasTitle(DataFilter<string, AdvertisementTab> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(AdvertisementTab.Title), "AdvertisementTab title is missing");

        [RegisterConditionValidator(typeof(AdvertisementTabValidatorStates), AdvertisementTabValidatorStates.HasAdvertisement)]
        private Task<ConditionResult> ValidateHasAdvertisement(DataFilter<string, AdvertisementTab> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(AdvertisementTab.AdvertisementId), "Advertisement ID is missing from tab");
    }
}

// ===== File: CategoryModelValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum CategoryModelValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName
    }

    public class CategoryModelValidator : ValidatorContext<CategoryModel, CategoryModelValidatorStates>
    {
        public CategoryModelValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(CategoryModelValidatorStates), CategoryModelValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, CategoryModel> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(CategoryModel.Id), "CategoryModel ID is missing");

        [RegisterConditionValidator(typeof(CategoryModelValidatorStates), CategoryModelValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, CategoryModel> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(CategoryModel.Name), "CategoryModel name is missing");
    }
}

// ===== File: EventRequestValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum EventRequestValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasStatus = GeneralValidatorStates.HasValidStatus,
        HasRequest // Check RequestId property
    }

    public class EventRequestValidator : ValidatorContext<EventRequest, EventRequestValidatorStates>
    {
        public EventRequestValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(EventRequestValidatorStates), EventRequestValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, EventRequest> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(EventRequest.Id), "EventRequest ID is missing");

        [RegisterConditionValidator(typeof(EventRequestValidatorStates), EventRequestValidatorStates.HasStatus)]
        private Task<ConditionResult> ValidateHasStatus(DataFilter<string, EventRequest> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(EventRequest.Status), "EventRequest status is missing");

        [RegisterConditionValidator(typeof(EventRequestValidatorStates), EventRequestValidatorStates.HasRequest)]
        private Task<ConditionResult> ValidateHasRequest(DataFilter<string, EventRequest> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(EventRequest.RequestId), "Request ID is missing from event");
    }
}

// ===== File: InvoiceValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum InvoiceValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasCustomerId,
        HasStatus = GeneralValidatorStates.HasValidStatus,
        HasUrl = GeneralValidatorStates.HasValidUri
    }

    public class InvoiceValidator : ValidatorContext<Invoice, InvoiceValidatorStates>
    {
        public InvoiceValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(InvoiceValidatorStates), InvoiceValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Invoice> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Invoice.Id), "Invoice ID is missing");

        [RegisterConditionValidator(typeof(InvoiceValidatorStates), InvoiceValidatorStates.HasCustomerId)]
        private Task<ConditionResult> ValidateHasCustomerId(DataFilter<string, Invoice> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Invoice.CustomerId), "Customer ID is missing from invoice");

        [RegisterConditionValidator(typeof(InvoiceValidatorStates), InvoiceValidatorStates.HasStatus)]
        private Task<ConditionResult> ValidateHasStatus(DataFilter<string, Invoice> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Invoice.Status), "Invoice status is missing");

        [RegisterConditionValidator(typeof(InvoiceValidatorStates), InvoiceValidatorStates.HasUrl)]
        private Task<ConditionResult> ValidateHasUrl(DataFilter<string, Invoice> f) =>
            ValidateUri(f, nameof(Invoice.Url), "Invalid or missing URL for invoice");
    }
}

// ===== File: LanguageValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum LanguageValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName,
        HasCode
    }

    public class LanguageValidator : ValidatorContext<Language, LanguageValidatorStates>
    {
        public LanguageValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(LanguageValidatorStates), LanguageValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Language> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Language.Id), "Language ID is missing");

        [RegisterConditionValidator(typeof(LanguageValidatorStates), LanguageValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, Language> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Language.Name), "Language name is missing");

        [RegisterConditionValidator(typeof(LanguageValidatorStates), LanguageValidatorStates.HasCode)]
        private Task<ConditionResult> ValidateHasCode(DataFilter<string, Language> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Language.Code), "Language code is missing");
    }
}

// ===== File: ModelAiValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum ModelAiValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName,
        HasModelGateway, // Check ModelGatewayId
        HasAbsolutePath = GeneralValidatorStates.HasValidUri,
        HasService // Check if Services collection is not empty or linked via FK (needs custom logic beyond simple check)
    }

    public class ModelAiValidator : ValidatorContext<ModelAi, ModelAiValidatorStates>
    {
        public ModelAiValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(ModelAiValidatorStates), ModelAiValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, ModelAi> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ModelAi.Id), "ModelAi ID is missing");

        [RegisterConditionValidator(typeof(ModelAiValidatorStates), ModelAiValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, ModelAi> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ModelAi.Name), "ModelAi name is missing");

        [RegisterConditionValidator(typeof(ModelAiValidatorStates), ModelAiValidatorStates.HasModelGateway)]
        private Task<ConditionResult> ValidateHasModelGateway(DataFilter<string, ModelAi> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ModelAi.ModelGatewayId), "ModelGateway ID is missing from ModelAi");

        [RegisterConditionValidator(typeof(ModelAiValidatorStates), ModelAiValidatorStates.HasAbsolutePath)]
        private Task<ConditionResult> ValidateHasAbsolutePath(DataFilter<string, ModelAi> f) =>
           ValidateUri(f, nameof(ModelAi.AbsolutePath), "Invalid or missing AbsolutePath for ModelAi");

        // Example of a more complex check (checking if linked to service - might need DB query)
        [RegisterConditionValidator(typeof(ModelAiValidatorStates), ModelAiValidatorStates.HasService)]
        private Task<ConditionResult> ValidateHasService(DataFilter<string, ModelAi> f) =>
             ValidateCollectionNotEmpty(f, nameof(ModelAi.Services), "Model AI is not linked to any service");

    }
}






namespace LAHJAAPI.Validators.v1
{
    public enum ModelGatewayValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName,
        HasUrl = GeneralValidatorStates.HasValidUri,
        IsDefault = GeneralValidatorStates.IsDefault
    }

    public class ModelGatewayValidator : ValidatorContext<ModelGateway, ModelGatewayValidatorStates>
    {
        public ModelGatewayValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(ModelGatewayValidatorStates), ModelGatewayValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, ModelGateway> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ModelGateway.Id), "ModelGateway ID is missing");

        [RegisterConditionValidator(typeof(ModelGatewayValidatorStates), ModelGatewayValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, ModelGateway> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(ModelGateway.Name), "ModelGateway name is missing");

        [RegisterConditionValidator(typeof(ModelGatewayValidatorStates), ModelGatewayValidatorStates.HasUrl)]
        private Task<ConditionResult> ValidateHasUrl(DataFilter<string, ModelGateway> f) =>
            ValidateUri(f, nameof(ModelGateway.Url), "Invalid or missing URL for ModelGateway");

        [RegisterConditionValidator(typeof(ModelGatewayValidatorStates), ModelGatewayValidatorStates.IsDefault)]
        private Task<ConditionResult> ValidateIsDefault(DataFilter<string, ModelGateway> f) =>
            ValidateBoolProperty(f, nameof(ModelGateway.IsDefault), true, "ModelGateway is not the default");
    }
}

// ===== File: PaymentValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum PaymentValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasCustomerId,
        HasInvoiceId,
        HasStatus = GeneralValidatorStates.HasValidStatus,
        HasAmount,
        HasCurrency
    }

    public class PaymentValidator : ValidatorContext<Payment, PaymentValidatorStates>
    {
        public PaymentValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(PaymentValidatorStates), PaymentValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Payment> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Payment.Id), "Payment ID is missing");

        [RegisterConditionValidator(typeof(PaymentValidatorStates), PaymentValidatorStates.HasCustomerId)]
        private Task<ConditionResult> ValidateHasCustomerId(DataFilter<string, Payment> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Payment.CustomerId), "Customer ID is missing from payment");

        [RegisterConditionValidator(typeof(PaymentValidatorStates), PaymentValidatorStates.HasInvoiceId)]
        private Task<ConditionResult> ValidateHasInvoiceId(DataFilter<string, Payment> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Payment.InvoiceId), "Invoice ID is missing from payment");

        [RegisterConditionValidator(typeof(PaymentValidatorStates), PaymentValidatorStates.HasStatus)]
        private Task<ConditionResult> ValidateHasStatus(DataFilter<string, Payment> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Payment.Status), "Payment status is missing");

        [RegisterConditionValidator(typeof(PaymentValidatorStates), PaymentValidatorStates.HasAmount)]
        private Task<ConditionResult> ValidateHasAmount(DataFilter<string, Payment> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Payment.Amount), "Payment amount is missing"); // Consider validating > 0

        [RegisterConditionValidator(typeof(PaymentValidatorStates), PaymentValidatorStates.HasCurrency)]
        private Task<ConditionResult> ValidateHasCurrency(DataFilter<string, Payment> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Payment.Currency), "Payment currency is missing");
    }
}

// ===== File: PlanValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum PlanValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasProductId,
        HasProductName,
        IsActive, // Using Active property
        HasBillingPeriod,
        HasAmount,
        HasFeatures, // Check PlanFeatures collection
        HasServices // Check PlanServices collection
    }

    public class PlanValidator : ValidatorContext<Plan, PlanValidatorStates>
    {
        public PlanValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Plan> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Plan.Id), "Plan ID is missing");

        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.HasProductId)]
        private Task<ConditionResult> ValidateHasProductId(DataFilter<string, Plan> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Plan.ProductId), "Product ID is missing from plan");

        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.HasProductName)]
        private Task<ConditionResult> ValidateHasProductName(DataFilter<string, Plan> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Plan.ProductName), "Product name is missing from plan");

        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.IsActive)]
        private Task<ConditionResult> ValidateIsActive(DataFilter<string, Plan> f) =>
            ValidateBoolProperty(f, nameof(Plan.Active), true, "Plan is not active");

        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.HasBillingPeriod)]
        private Task<ConditionResult> ValidateHasBillingPeriod(DataFilter<string, Plan> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Plan.BillingPeriod), "Billing period is missing from plan");

        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.HasAmount)]
    
        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.HasFeatures)]
        private Task<ConditionResult> ValidateHasFeatures(DataFilter<string, Plan> f) =>
            ValidateCollectionNotEmpty(f, nameof(Plan.PlanFeatures), "Plan has no defined features");

        [RegisterConditionValidator(typeof(PlanValidatorStates), PlanValidatorStates.HasServices)]
        private Task<ConditionResult> ValidateHasServices(DataFilter<string, Plan> f) =>
            ValidateCollectionNotEmpty(f, nameof(Plan.PlanServices), "Plan has no defined services");
    }
}

// ===== File: PlanFeatureValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum PlanFeatureValidatorStates
    {
        HasId, // Integer ID
        HasKey,
        HasName = GeneralValidatorStates.HasName,
        HasDescription = GeneralValidatorStates.HasDescription,
        HasPlan // Check PlanId property
    }

    public class PlanFeatureValidator : ValidatorContext<PlanFeature, PlanFeatureValidatorStates>
    {
        public PlanFeatureValidator(IConditionChecker checker) : base(checker) { }

        // Note: Base context ValidatePropertyExists might work for int if underlying logic handles it.
        // If DataFilter assumes string ID, this needs adjustment in base or here.
        [RegisterConditionValidator(typeof(PlanFeatureValidatorStates), PlanFeatureValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, PlanFeature> f) => // Assuming string ID filter for now
             ValidatePropertyExists(f, nameof(PlanFeature.Id), "PlanFeature ID is missing");
        // If filter uses int: DataFilter<int, PlanFeature> f
        // ValidateNumericPropertyGreaterThanZero(f, nameof(PlanFeature.Id), "PlanFeature ID is missing");


        [RegisterConditionValidator(typeof(PlanFeatureValidatorStates), PlanFeatureValidatorStates.HasKey)]
        private Task<ConditionResult> ValidateHasKey(DataFilter<string, PlanFeature> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(PlanFeature.Key), "PlanFeature key is missing");

        [RegisterConditionValidator(typeof(PlanFeatureValidatorStates), PlanFeatureValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, PlanFeature> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(PlanFeature.Name), "PlanFeature name is missing");

        [RegisterConditionValidator(typeof(PlanFeatureValidatorStates), PlanFeatureValidatorStates.HasDescription)]
        private Task<ConditionResult> ValidateHasDescription(DataFilter<string, PlanFeature> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(PlanFeature.Description), "PlanFeature description is missing");

        [RegisterConditionValidator(typeof(PlanFeatureValidatorStates), PlanFeatureValidatorStates.HasPlan)]
        private Task<ConditionResult> ValidateHasPlan(DataFilter<string, PlanFeature> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(PlanFeature.PlanId), "Plan ID is missing from feature");
    }
}

// ===== File: RequestValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum RequestValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasStatus = GeneralValidatorStates.HasValidStatus,
        HasQuestion,
        HasUser, // Check UserId property
        HasService, // Check ServiceId property
        HasSubscription, // Check SubscriptionId property
        HasSpace // Check SpaceId property
    }

    public class RequestValidator : ValidatorContext<Request, RequestValidatorStates>
    {
        public RequestValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(RequestValidatorStates), RequestValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Request> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Request.Id), "Request ID is missing");

        [RegisterConditionValidator(typeof(RequestValidatorStates), RequestValidatorStates.HasStatus)]
        private Task<ConditionResult> ValidateHasStatus(DataFilter<string, Request> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Request.Status), "Request status is missing");

        [RegisterConditionValidator(typeof(RequestValidatorStates), RequestValidatorStates.HasQuestion)]
        private Task<ConditionResult> ValidateHasQuestion(DataFilter<string, Request> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Request.Question), "Request question is missing");

        [RegisterConditionValidator(typeof(RequestValidatorStates), RequestValidatorStates.HasUser)]
        private Task<ConditionResult> ValidateHasUser(DataFilter<string, Request> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Request.UserId), "User ID is missing from request");

        [RegisterConditionValidator(typeof(RequestValidatorStates), RequestValidatorStates.HasService)]
        private Task<ConditionResult> ValidateHasService(DataFilter<string, Request> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Request.ServiceId), "Service ID is missing from request");

        [RegisterConditionValidator(typeof(RequestValidatorStates), RequestValidatorStates.HasSubscription)]
        private Task<ConditionResult> ValidateHasSubscription(DataFilter<string, Request> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Request.SubscriptionId), "Subscription ID is missing from request");

        [RegisterConditionValidator(typeof(RequestValidatorStates), RequestValidatorStates.HasSpace)]
        private Task<ConditionResult> ValidateHasSpace(DataFilter<string, Request> f) =>
           ValidateStringPropertyNotEmpty(f, nameof(Request.SpaceId), "Space ID is missing from request"); // Optional, depends on logic
    }
}

// ===== File: SettingValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum SettingValidatorStates
    {
        HasName = GeneralValidatorStates.HasName, // Name is the key
        HasValue
    }

    public class SettingValidator : ValidatorContext<Setting, SettingValidatorStates>
    {
        // Need to adjust GetModel if ID is Name (string)
        public SettingValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(SettingValidatorStates), SettingValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, Setting> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Setting.Name), "Setting name (key) is missing");

        [RegisterConditionValidator(typeof(SettingValidatorStates), SettingValidatorStates.HasValue)]
        private Task<ConditionResult> ValidateHasValue(DataFilter<string, Setting> f) =>
            ValidatePropertyExists(f, nameof(Setting.Value), "Setting value is missing"); // Value can be null, so check existence
    }
}

// ===== File: SpaceValidator.cs =====





namespace LAHJAAPI.Validators.v1
{
    public enum SpaceValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasName = GeneralValidatorStates.HasName,
        HasToken,
        HasSubscription // Check SubscriptionId property
    }

    public class SpaceValidator : ValidatorContext<Space, SpaceValidatorStates>
    {
        public SpaceValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(SpaceValidatorStates), SpaceValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Space> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Space.Id), "Space ID is missing");

        [RegisterConditionValidator(typeof(SpaceValidatorStates), SpaceValidatorStates.HasName)]
        private Task<ConditionResult> ValidateHasName(DataFilter<string, Space> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Space.Name), "Space name is missing");

        [RegisterConditionValidator(typeof(SpaceValidatorStates), SpaceValidatorStates.HasToken)]
        private Task<ConditionResult> ValidateHasToken(DataFilter<string, Space> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Space.Token), "Space token is missing");

        [RegisterConditionValidator(typeof(SpaceValidatorStates), SpaceValidatorStates.HasSubscription)]
        private Task<ConditionResult> ValidateHasSubscription(DataFilter<string, Space> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Space.SubscriptionId), "Subscription ID is missing from space");
    }
}



namespace LAHJAAPI.Validators.v1
{
    public enum SubscriptionValidatorStates
    {
        HasId = GeneralValidatorStates.HasId,
        HasCustomerId,
        HasStatus = GeneralValidatorStates.HasValidStatus,
        HasUser, // Check UserId property
        HasPlan, // Check PlanId property
        IsActive, // Check status == 'active' (needs specific value check)
        IsNotCancelled, // Check CancelAtPeriodEnd == false
        HasValidDates // Check CurrentPeriodStart < CurrentPeriodEnd
    }

    public class SubscriptionValidator : ValidatorContext<Subscription, SubscriptionValidatorStates>
    {
        public SubscriptionValidator(IConditionChecker checker) : base(checker) { }

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.HasId)]
        private Task<ConditionResult> ValidateHasId(DataFilter<string, Subscription> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Subscription.Id), "Subscription ID is missing");

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.HasCustomerId)]
        private Task<ConditionResult> ValidateHasCustomerId(DataFilter<string, Subscription> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Subscription.CustomerId), "Customer ID is missing from subscription");

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.HasStatus)]
        private Task<ConditionResult> ValidateHasStatus(DataFilter<string, Subscription> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Subscription.Status), "Subscription status is missing");

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.HasUser)]
        private Task<ConditionResult> ValidateHasUser(DataFilter<string, Subscription> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Subscription.UserId), "User ID is missing from subscription");

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.HasPlan)]
        private Task<ConditionResult> ValidateHasPlan(DataFilter<string, Subscription> f) =>
            ValidateStringPropertyNotEmpty(f, nameof(Subscription.PlanId), "Plan ID is missing from subscription");

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.IsActive)]
        private Task<ConditionResult> ValidateIsActive(DataFilter<string, Subscription> f) =>
            ValidateStringPropertyValue(f, nameof(Subscription.Status), "active", "Subscription is not active"); // Assuming 'active' status

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.IsNotCancelled)]
        private Task<ConditionResult> ValidateIsNotCancelled(DataFilter<string, Subscription> f) =>
            ValidateBoolProperty(f, nameof(Subscription.CancelAtPeriodEnd), false, "Subscription is set to cancel at period end");

        [RegisterConditionValidator(typeof(SubscriptionValidatorStates), SubscriptionValidatorStates.HasValidDates)]
        private Task<ConditionResult> ValidateHasValidDates(DataFilter<string, Subscription> f)
        {
            bool valid = f.Share != null && f.Share.CurrentPeriodStart < f.Share.CurrentPeriodEnd;
            return valid
                ? ConditionResult.ToSuccessAsync(true)
                : ConditionResult.ToFailureAsync(false, "Subscription period start date is not before end date");
        }
    }
}

