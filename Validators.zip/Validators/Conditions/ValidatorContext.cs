using AutoGenerator;
using AutoGenerator.Conditions;
using System;

namespace ApiCore.Validators.Conditions
{
    public abstract class ValidatorContext<TContext, EValidator> : BaseValidatorContext<TContext, EValidator>, ITValidator where TContext : class where EValidator : Enum
    {
        protected readonly ITFactoryInjector _injector;
        public ValidatorContext(IConditionChecker checker) : base(checker)
        {
            _injector = checker.Injector;
        }

        protected Task<ConditionResult> ValidateStringPropertyNotEmpty(DataFilter<string, TContext> f, string propertyName, string errorMsg)
        {
            var value = f.Share?.GetType().GetProperty(propertyName)?.GetValue(f.Share)?.ToString();
            bool valid = !string.IsNullOrWhiteSpace(value);
            return valid ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(value, errorMsg);
        }

        protected Task<ConditionResult> ValidateNumericPropertyGreaterThanZero<TNum>(DataFilter<string, TContext> f, string propertyName, string errorMsg) where TNum : struct, IComparable, IComparable<TNum>, IConvertible, IEquatable<TNum>, IFormattable
        {
            var propInfo = f.Share?.GetType().GetProperty(propertyName);
            if (propInfo == null || propInfo.PropertyType != typeof(TNum))
            {
                return ConditionResult.ToFailureAsync(null, $"Property {propertyName} not found or not of type {typeof(TNum).Name}");
            }

            var value = (TNum?)propInfo.GetValue(f.Share);
            bool valid = value.HasValue && Comparer<TNum>.Default.Compare(value.Value, default(TNum)) > 0;

            return valid ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(value, errorMsg);
        }
        protected Task<ConditionResult> ValidatePropertyExists(DataFilter<string, TContext> f, string propertyName, string errorMsg)
        {
            var value = f.Share?.GetType().GetProperty(propertyName)?.GetValue(f.Share);
            return value != null ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(null, errorMsg);
        }

        protected Task<ConditionResult> ValidateBoolProperty(DataFilter<string, TContext> f, string propertyName, bool expected, string errorMsg)
        {
            var value = f.Share?.GetType().GetProperty(propertyName)?.GetValue(f.Share) as bool?;
            return value == expected ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(value, errorMsg);
        }

        protected Task<ConditionResult> ValidateCollectionNotEmpty(DataFilter<string, TContext> f, string propertyName, string errorMsg)
        {
            var value = f.Share?.GetType().GetProperty(propertyName)?.GetValue(f.Share) as System.Collections.IEnumerable;
            var hasItems = value?.Cast<object>().Any() ?? false;
            return hasItems ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(null, errorMsg);
        }

        protected Task<ConditionResult> ValidateUri(DataFilter<string, TContext> f, string propertyName, string errorMsg)
        {
            var value = f.Share?.GetType().GetProperty(propertyName)?.GetValue(f.Share)?.ToString();
            bool valid = Uri.IsWellFormedUriString(value, UriKind.Absolute);
            return valid ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(value, errorMsg);
        }

        protected Task<ConditionResult> ValidateEmail(DataFilter<string, TContext> f, string propertyName, string errorMsg)
        {
            var value = f.Share?.GetType().GetProperty(propertyName)?.GetValue(f.Share)?.ToString();
            bool valid = !string.IsNullOrEmpty(value) && System.Text.RegularExpressions.Regex.IsMatch(value, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            return valid ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(value, errorMsg);
        }

        protected Task<ConditionResult> ValidateStringPropertyValue(DataFilter<string, TContext> f, string propertyName, string expectedValue, string errorMsg, bool ignoreCase = true)
        {
            var value = f.Share?.GetType().GetProperty(propertyName)?.GetValue(f.Share)?.ToString();
            bool valid = string.Equals(value, expectedValue, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
            return valid ? ConditionResult.ToSuccessAsync(value) : ConditionResult.ToFailureAsync(value, errorMsg);
        }
        protected virtual async Task<TContext?> FinModel(string? id)
        {
            var _model = await _injector.Context.Set<TContext>().FindAsync(id);
            return _model;
        }

        protected override Task<TContext?> GetModel(string? id)
        {
            return FinModel(id);
        }
    }
}