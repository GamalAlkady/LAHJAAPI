using System;

namespace Validators.Conditions
{
    public class BaseConditionsValidators
    {
        public BaseConditionsValidators()
        {
            Console.WriteLine("Base class initialized in BaseConditionsValidators");
        }
    }
}