using Api.SM.Data;
using AutoGenerator;
using AutoGenerator.Conditions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Reflection;

namespace V1.Validators.Conditions
{
    public class SingletonContextFactory
    {
        private readonly IServiceScopeFactory _scopeFactory;

        public SingletonContextFactory(IServiceScopeFactory scopeFactory)
        {
            _scopeFactory = scopeFactory;

        }

        public DataContext GetDataContext()
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<DataContext>();

                // ������ ������ ��� �����
                return context;
            }
        }

        public DbSet<TEntity> GetDbSet<TEntity>() where TEntity : class
        {
            using (var scope = _scopeFactory.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<DataContext>();
                return context.Set<TEntity>();
            }
        }


    }
    public static class ConfigValidator
    {
        public static IServiceCollection AddAutoValidator(this IServiceCollection serviceCollection)
        {
            Assembly? assembly = Assembly.GetExecutingAssembly();
            serviceCollection.AddSingleton<SingletonContextFactory>();
            serviceCollection.AddSingleton<ITFactoryInjector, TFactoryInjector>();
            serviceCollection.AddSingleton<IConditionChecker, ConditionChecker>(pro =>
            {
                var injctor = pro.GetRequiredService<ITFactoryInjector>();
                var checker = new ConditionChecker(injctor);
                BaseConfigValidator.Register(checker, assembly);
                return checker;
            });
            return serviceCollection;
        }
    }
}