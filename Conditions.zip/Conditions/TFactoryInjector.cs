using AutoGenerator;
using AutoGenerator.Conditions;
using AutoGenerator.Notifications;
using AutoMapper;
using Api.SM.Data;
using System;

namespace V1.Validators.Conditions
{
    public class TFactoryInjector : TBaseFactoryInjector, ITFactoryInjector
    {
        private readonly SingletonContextFactory _contextFactory;
        public TFactoryInjector(IMapper mapper, IAutoNotifier notifier, SingletonContextFactory  contextFactory) : base(mapper, notifier)
        {

            _contextFactory = contextFactory;
        }

        public SingletonContextFactory ContextFactory => _contextFactory;


        // يمكنك حقن اي طبقة
    }
}