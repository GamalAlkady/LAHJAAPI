using AutoGenerator;
using AutoGenerator.Conditions;
using AutoMapper;
using Api.SM.Data;
using System;

namespace V1.Validators.Conditions
{
    public interface ITFactoryInjector : ITBaseFactoryInjector
    {
        public SingletonContextFactory  ContextFactory { get; }
    }
}