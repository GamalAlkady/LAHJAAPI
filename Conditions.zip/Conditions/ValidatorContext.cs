using AutoGenerator;
using AutoGenerator.Conditions;
using Microsoft.EntityFrameworkCore;
using System;

namespace V1.Validators.Conditions
{
    public abstract class ValidatorContext<TContext, EValidator> : BaseValidatorContext<TContext, EValidator>, ITValidator where TContext : class where EValidator : Enum
    {
        protected readonly ITFactoryInjector _injector;
        public ValidatorContext(IConditionChecker checker) : base(checker)
        {
            _injector = checker.Injector;
        }

        protected  DbSet<TContext> DbSet=> GetDbSet<TContext>();
        protected virtual DbSet<T> GetDbSet<T>()
            where T : class
        {
            return _injector.ContextFactory.GetDbSet<T>();
        }


        protected virtual async Task<TContext?> FinModel(string? id)
        {
            var _model = await DbSet.FindAsync(id);
            return _model;
        }

        protected override Task<TContext?> GetModel(string? id)
        {
            return FinModel(id);
        }
    }
}